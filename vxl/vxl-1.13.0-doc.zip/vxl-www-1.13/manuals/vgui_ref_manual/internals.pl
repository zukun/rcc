# LaTeX2HTML 98.1 release (February 19th, 1998)
# Associate internals original text with physical files.


$key = q/fig1/;
$ref_files{$key} = "$dir".q|node3.html|; 
$noresave{$key} = "$nosave";

1;

