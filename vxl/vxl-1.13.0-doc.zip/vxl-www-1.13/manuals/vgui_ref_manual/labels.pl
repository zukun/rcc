# LaTeX2HTML 98.1 release (February 19th, 1998)
# Associate labels original text with physical files.


$key = q/fig1/;
$external_labels{$key} = "$URL/" . q|node3.html|; 
$noresave{$key} = "$nosave";

1;

