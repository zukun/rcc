# LaTeX2HTML 98.1 release (February 19th, 1998)
# Associate images original text with physical files.


$key = q/{inline}mboxbullet{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img2.gif"
 ALT="$\mbox{$\bullet$}$">|; 

$key = q/{inline}ldots{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="img3.gif"
 ALT="$\ldots$">|; 

$key = q/{inline}150times250{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="84" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="img4.gif"
 ALT="$150 \times
250$">|; 

$key = q/{inline}rightarrow{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="30" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="img1.gif"
 ALT="$\rightarrow\ $">|; 

1;

