# LaTeX2HTML 98.1 release (February 19th, 1998)
# Associate images original text with physical files.


$key = q/{inline}mboxbullet{inline}MSF=1.6;AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="img3.gif"
 ALT="$\mbox{$\bullet$}$">|; 

$key = q/{center}vbox{input{2d-example}}{center}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="578" HEIGHT="574" ALIGN="BOTTOM" BORDER="0"
 SRC="img6.gif"
 ALT="\begin{center}\vbox{\input{2d-example}
}\end{center}">|; 

$key = q/{center}vbox{input{draw-line}}{center}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="376" HEIGHT="422" ALIGN="BOTTOM" BORDER="0"
 SRC="img5.gif"
 ALT="\begin{center}\vbox{\input{draw-line}
}\end{center}">|; 

$key = q/{center}vbox{input{menubar-example}}{center}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="548" HEIGHT="679" ALIGN="BOTTOM" BORDER="0"
 SRC="img7.gif"
 ALT="\begin{center}\vbox{\input{menubar-example}
}\end{center}">|; 

$key = q/{verbawf}unix<comment_mark>{verbawf}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="56" HEIGHT="12" ALIGN="BOTTOM" BORDER="0"
 SRC="img2.gif"
 ALT="\begin{verbawf}unix%
\end{verbawf}">|; 

$key = q/{verbawf}unix<comment_mark>unix<comment_mark>unix<comment_mark>unix<comment_mark>{verbawf}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="56" HEIGHT="81" ALIGN="BOTTOM" BORDER="0"
 SRC="img1.gif"
 ALT="\begin{verbawf}unix%
unix%
unix%
unix%
\end{verbawf}">|; 

$key = q/{center}vbox{input{display-image}}{center}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="448" HEIGHT="317" ALIGN="BOTTOM" BORDER="0"
 SRC="img4.gif"
 ALT="\begin{center}\vbox{\input{display-image}
}\end{center}">|; 

$key = q/{center}vbox{input{rubberband}}{center}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="577" HEIGHT="602" ALIGN="BOTTOM" BORDER="0"
 SRC="img12.gif"
 ALT="\begin{center}\vbox{\input{rubberband}
}\end{center}">|; 

$key = q/{center}vbox{input{gtk-display-image}}{center}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="600" HEIGHT="604" ALIGN="BOTTOM" BORDER="0"
 SRC="img14.gif"
 ALT="\begin{center}\vbox{\input{gtk-display-image}
}\end{center}">|; 

$key = q/{center}vbox{input{mouse-position}}{center}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="622" HEIGHT="842" ALIGN="BOTTOM" BORDER="0"
 SRC="img10.gif"
 ALT="\begin{center}\vbox{\input{mouse-position}
}\end{center}">|; 

$key = q/{center}vbox{input{popup-example}}{center}AAT;/;
$cached_env_img{$key} = q|<IMG
 WIDTH="694" HEIGHT="831" ALIGN="BOTTOM" BORDER="0"
 SRC="img8.gif"
 ALT="\begin{center}\vbox{\input{popup-example}
}\end{center}">|; 

1;

